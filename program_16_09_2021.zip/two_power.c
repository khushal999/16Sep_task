
#include <stdio.h>
int two_power(int n)
{
	if (n == 0)
           return 0;
       
       	if ((n & (~(n - 1))) == n)
           return 1;
       
       	return 0;

}


int main()
{
	int val;
	printf("\n Enter a value:: ");
	scanf("%d",&val);
	if(two_power(val))
	        printf("\n Number is power of two");
	else
		printf("\n Number is not power of two");

	return 0;
}




/*EOC*/
