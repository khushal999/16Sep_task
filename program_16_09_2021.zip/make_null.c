#include<stdio.h>

void modify(int *a)
{
	*a=10;
	a=NULL;

}
int main()
{
	int x=5;
	int *p=&x;
	printf("\n %p  %u",p,x); // 0x2000  5
	modify(p);
	printf("\n %p  %u",p,x);// 0x2000   10
	p=NULL;
	printf("\n %p  %u",p,x);// nil 10
	return 0;

}
