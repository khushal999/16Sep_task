
#include <stdio.h>
int count_bits(int val)
{
	int count = 0;
	while (val) 
	{
		count += val & 1;
		val >>= 1;
	}
	return count;
}


int main()
{
	int val;
	printf("\n Enter a value:: ");
	scanf("%d",&val);
	printf("\n Total number of 1's: %d\n", count_bits(val));
	return 0;
}




/*EOC*/
