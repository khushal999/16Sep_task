
#include <stdio.h>

int toggle_bits(int val)
{
	int count = 0, n_bit;
	int new_val;
	printf("Enter nth bit to toggle:: ");
        scanf("%d", &n_bit);
	
	new_val= val ^ (1 << n_bit);

	return new_val;
}


int main()
{
	int val;
	printf("\n Enter a value:: ");
	scanf("%d",&val);
	printf("\n New number: %d\n", toggle_bits(val));
	return 0;
}




/*EOC*/
