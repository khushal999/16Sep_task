#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/ioctl.h>

#define MAX_SIZE 1024
int8_t write_buf[MAX_SIZE];
int8_t read_buf[MAX_SIZE];

#define WR_VALUE _IOW('a','a',int*) 
#define RD_VALUE _IOR('a','b',int*)


int main()
{
	int fd,fd_ioctl,fd_close,fd_write,fd_read;
	char option;
	int number = 0, value = 0, state=0;
	fd = open("/dev/my_Char_driver1",O_RDWR);
	if(fd<0){
		perror("Error: ");
		return 0;
	}	
	while(1){
		printf("\n****Please Enter the Option******\n"); 
		printf("        1. Write                 \n");
		printf("        2. Read                  \n");		
		printf("	3. IOCTL		 \n");
		printf("        4. Exit                  \n");
		printf("*********************************\n");
		scanf(" %c", &option);
		printf("Your Option:: %c\n", option);
		
		switch(option)
		{
			case '1':
				printf("Enter the string to write into driver :"); 
				scanf("  %[^\t\n]s", write_buf);
				if(strlen(write_buf) > MAX_SIZE)
				{
					printf("\n Entered string is bigger than %d, Hence input is discarded",MAX_SIZE);
					break;
				}

				printf("Data Writing ...");
				fd_write=write(fd, write_buf, strlen(write_buf)+1);
				if(fd_write>0)
				{
					state++;
					printf("Done!\n");
				}
				else
					perror("\n ERROR: ");				
				
				break;

			case '2':
				if(state)
				{	
			   		printf("Data Reading ...");
			   		fd_read=read(fd, read_buf, MAX_SIZE);
			   		if(fd_write>0)
					{
						printf("Done!\n");
						printf("Data = %s\n\n", read_buf);
					}
					else
						perror("\n ERROR: ");
			   	
				}
				else
					printf("\n File having no data...");
			   	break;

			case '3':	
				 printf("Enter the integer value to send\n"); 
				 scanf("%d",&number);

				 printf("Writing Value to Driver\n");
				 fd_ioctl= ioctl(fd, WR_VALUE, (int32_t*) &number);
 				 
				 if(fd_ioctl<0){
					perror("\n ERROR: ");
					break;
				 }

				 printf("Reading Value from Driver\n");
				 fd_ioctl= ioctl(fd, RD_VALUE, (int32_t*) &value);

 				 if(fd_ioctl<0)
					perror("\n ERROR: ");
				 else
				 	printf("Value is %d\n", value);

				 break;

		   	case '4':
				 fd_close= close(fd);
				 if(fd_close!=0)
					perror("\n ERROR: ");
				 
				 exit(1);
				 break;  // Break is optional

		   	default:
				 printf("Enter Valid option = %c\n",option);
				 break;
		}
	}

	fd_close = close(fd);
	if(fd_close!=0)
		perror("\n ERROR: ");

	return 0;
}





/*EOF*/


